import './App.css';
import User from './component/user';

function App() {
  return (
    <>
    <User></User>
    </>
  );
}

export default App;
